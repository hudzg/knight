<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.4" tiledversion="1.4.1" name="test" tilewidth="8" tileheight="8" tilecount="256" columns="16">
 <image source="tiles.png" width="128" height="128"/>
</tileset>
