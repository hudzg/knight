[ENG]
Hello everyone! I'm Reff. If you need anything or if there is something wrong with your purchase please contact me through any of the following means:

Website: www.reffpixels.com
Email: reffpixels@gmail.com
Twitter: https://twitter.com/ReffPixels
Itch.io: https://reffpixels.itch.io/
Reddit: https://www.reddit.com/user/_Reff/
Discord: Reff#5905

Can't find the icon you are looking for?
You can request new apps or icons  here: https://docs.google.com/forms/d/1S2Ufxrhw4uErAMunhXaRxVdTaQUTGiTeSGRM1gb7pyI/
I will be updating the set periodically as icons are requested.

LICENCE: 
Pixelart Icon Pack by @ReffPixels (Pablo Rodriguez) is licensed under a Creative Commons Attribution Non Comercial 4.0 International License.

This asset pack can be used for personal projects, but not commercially. You can modify it to suit your own needs. Credit is unnecessary, but highly appreciated (@ReffPixels).  
You may not redistribute, resell or take your own credit for this Asset Pack, a fraction of it, or a slightly modified version.